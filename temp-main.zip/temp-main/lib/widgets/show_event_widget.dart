import 'package:flutter/material.dart';

class EventDescription extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
