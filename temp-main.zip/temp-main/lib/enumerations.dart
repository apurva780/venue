enum CalendarView {
  month,
  day,
  week,
}
